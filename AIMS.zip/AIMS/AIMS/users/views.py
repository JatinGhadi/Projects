from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from users.forms import RegisterForm


# Create your views here.

def index(request):

    context = {

    }

    return render(request, 'users/home.html', context)

# Login view
# ------------------------------------------------------------------------------------------
def login_view(request):
    
    if request.method == "POST":

        # using username
        # ---------------------------------------------
        username = request.POST['username']
        password = request.POST['password']

        # using first name
        # -------------------------------------------
        # firstname = request.POST['firstname']
        # password = request.POST['password']
        # userobj = User.objects.get(first_name=firstname)
        # username=userobj.username

        user = authenticate(username=username, password=password)

        if user is None:
            messages.success(
                request,
                'invalid id login, try again'
            )
            return redirect('index')
        
        if user.is_superuser:
            messages.success(
                request,
                'Welcome superuser {}, you have been successfully logged in'.format(username)
            )
            login(request, user)
            return redirect('index')
        
        if user is not None:
            messages.success(
                request,
                'Welcome {}, you have been successfully logged in'.format(username)
            )
            login(request, user)
            return redirect('index')

    context = {

    }

    return render(request, 'users/login.html', context)

# Logout view
# ------------------------------------------------------------------------------------------
def logout_view(request):

    if request.method == 'POST':
        logout(request)
        return redirect('index')

    return render(request, 'users/logout.html')

# register
#-------------------------------------------------------------------------------------------------------------
def register(request):

    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if form.is_valid():
            username = form.cleaned_data.get('username')
            form.save()
            messages.success(
                request,
                'Welcome, {} your account has been successfully created'.format(username)
            )
            return redirect('login')

    else:
        form = RegisterForm(None)

    context = {
        'form':form
    }
    
    return render(request, 'users/register.html', context)