
from django.contrib import admin
from django.urls import path, include
from . import views
from users import views as usersviews

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('dashboard/', include('dashboard.urls')),
    path('users/', include('users.urls')),
    path('user/', usersviews.register, name='register'),
    path('login/',usersviews.login_view,name='login'),
    path('logout/',usersviews.logout_view,name='logout'),
    path('register/', usersviews.register, name='register'),
    
]
